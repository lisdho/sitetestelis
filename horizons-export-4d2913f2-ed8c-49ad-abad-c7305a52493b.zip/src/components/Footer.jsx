
import React from 'react';
import { MessageCircle, Mail, Linkedin, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

const Footer = () => {
  const quickLinks = [
    { label: 'Quem Somos', href: '#quem-somos' },
    { label: 'Soluções', href: '#solucoes' },
    { label: 'Como Trabalhamos', href: '#como-trabalhamos' },
    { label: 'Diferenciais', href: '#diferenciais' }
  ];

  const contactInfo = [
    { icon: MessageCircle, label: 'WhatsApp', value: '+55 11 99999-9999', color: '#FF2D83' },
    { icon: Mail, label: 'Email', value: 'contato@lenspartner.com', color: '#BDA0FF' },
    { icon: Linkedin, label: 'LinkedIn', value: '/lenspartner', color: '#FF2D83' }
  ];

  return (
    <footer id="contato" className="bg-[#07070B] border-t border-white/10 py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Sobre */}
          <div>
            <h3 className="text-xl font-bold text-[#F4F4F8] mb-4 bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
              Sobre
            </h3>
            <p className="text-[#C7C7D6] leading-relaxed mb-4">
              LENS Partner é uma consultoria que integra dados, método e desenvolvimento humano para resultados sustentáveis.
            </p>
            <div className="text-2xl font-bold text-[#F4F4F8] tracking-tight">
              LENS Partner
            </div>
          </div>

          {/* Links Rápidos */}
          <div>
            <h3 className="text-xl font-bold text-[#F4F4F8] mb-4 bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
              Links Rápidos
            </h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-[#C7C7D6] hover:text-[#FF2D83] transition-colors duration-300 flex items-center gap-2"
                    onClick={(e) => {
                      e.preventDefault();
                      const element = document.querySelector(link.href);
                      if (element) {
                        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }
                    }}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-[#FF2D83]"></span>
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h3 className="text-xl font-bold text-[#F4F4F8] mb-4 bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
              Contato
            </h3>
            <div className="space-y-3">
              {contactInfo.map((contact, index) => (
                <motion.div
                  key={index}
                  className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-3 hover:bg-white/10 transition-all duration-300 hover:border-white/20 hover:shadow-lg"
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="flex items-center gap-3">
                    <contact.icon 
                      size={20} 
                      style={{ color: contact.color }}
                      className="flex-shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="text-xs text-[#C7C7D6] mb-0.5">{contact.label}</div>
                      <div className="text-sm text-[#F4F4F8] truncate">{contact.value}</div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-8 border-t border-white/10">
          <p className="text-center text-[#C7C7D6] text-sm">
            © {new Date().getFullYear()} LENS Partner. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
