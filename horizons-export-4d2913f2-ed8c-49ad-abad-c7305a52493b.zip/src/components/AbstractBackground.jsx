
import React from 'react';
import { motion } from 'framer-motion';

const AbstractBackground = () => {
  return (
    <div className="fixed inset-0 z-0 overflow-hidden bg-[#07070B] pointer-events-none">
      <svg
        className="absolute w-full h-full opacity-40"
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <filter id="blur-lg" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="15" />
          </filter>
          <filter id="blur-md" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="8" />
          </filter>
        </defs>

        {/* Lilás (#BDA0FF) - Top Left */}
        <motion.circle
          cx="20"
          cy="20"
          r="25"
          fill="#BDA0FF"
          filter="url(#blur-lg)"
          opacity="0.25"
          animate={{
            cx: ["20", "25", "15", "20"],
            cy: ["20", "15", "25", "20"],
            r: ["25", "28", "22", "25"]
          }}
          transition={{
            duration: 18,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        {/* Roxo escuro (#6B4FA0) - Right Center */}
        <motion.circle
          cx="80"
          cy="40"
          r="30"
          fill="#6B4FA0"
          filter="url(#blur-lg)"
          opacity="0.2"
          animate={{
            cx: ["80", "75", "85", "80"],
            cy: ["40", "45", "35", "40"],
            scale: [1, 1.1, 0.9, 1]
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        {/* Intermediate (#3D2E5F) - Bottom Left */}
        <motion.circle
          cx="30"
          cy="80"
          r="35"
          fill="#3D2E5F"
          filter="url(#blur-lg)"
          opacity="0.3"
          animate={{
            cx: ["30", "35", "25", "30"],
            cy: ["80", "75", "85", "80"],
          }}
          transition={{
            duration: 22,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        {/* Accent (#5A3F8F) - Bottom Right */}
        <motion.circle
          cx="90"
          cy="90"
          r="20"
          fill="#5A3F8F"
          filter="url(#blur-md)"
          opacity="0.25"
          animate={{
            cx: ["90", "85", "95", "90"],
            cy: ["90", "95", "85", "90"],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />

        {/* Floating Line - Smooth Abstract Flow */}
        <motion.path
          d="M0,50 Q50,30 100,50"
          fill="none"
          stroke="#4A3A6B"
          strokeWidth="0.5"
          strokeOpacity="0.4"
          filter="url(#blur-md)"
          animate={{
            d: [
              "M0,50 Q50,30 100,50",
              "M0,50 Q50,70 100,50",
              "M0,50 Q50,30 100,50"
            ]
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </svg>
      
      {/* Noise Texture Overlay for depth */}
      <div 
        className="absolute inset-0 opacity-[0.03] mix-blend-overlay"
        style={{ 
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")` 
        }}
      ></div>

      {/* Vignette Overlay */}
      <div 
        className="absolute inset-0 opacity-60"
        style={{
          background: 'radial-gradient(circle at center, transparent 0%, #07070B 100%)'
        }}
      ></div>
    </div>
  );
};

export default AbstractBackground;
