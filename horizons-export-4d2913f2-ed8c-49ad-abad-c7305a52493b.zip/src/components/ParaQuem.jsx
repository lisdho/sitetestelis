
import React from 'react';
import { motion } from 'framer-motion';
import { Building2, User, HeartHandshake as Handshake, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const ParaQuem = () => {
  const { toast } = useToast();

  const handleCTAClick = (type) => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "Esta funcionalidade será implementada em breve. Entre em contato através da seção de contato!",
    });
  };

  const cards = [
    {
      icon: Building2,
      title: 'Para Empresas',
      subtitle: 'B2B',
      color: '#FF2D83',
      painPoints: [
        'Baixo ROI em treinamentos e programas de desenvolvimento',
        'Custos invisíveis com turnover e retrabalho',
        'Alta rotatividade em posições estratégicas',
        'Liderança sobrecarregada sem tempo para pensar estratégia',
        'Cultura frágil que não sustenta os resultados'
      ],
      promise: 'Transformamos diagnósticos em planos de ação claros, com métricas reais e acompanhamento contínuo.',
      cta: 'Quero um diagnóstico',
      ctaAction: 'diagnostico'
    },
    {
      icon: User,
      title: 'Para Profissionais',
      subtitle: 'B2C',
      color: '#BDA0FF',
      painPoints: [
        'Carreira travada ou sem direção clara',
        'Medo de obsolescência profissional',
        'Falta de clareza sobre próximos passos',
        'Dificuldade em se posicionar no mercado',
        'Sensação de estar aquém do próprio potencial'
      ],
      promise: 'Direcionamos seu desenvolvimento com estratégias personalizadas, baseadas em dados de mercado e autoconhecimento.',
      cta: 'Quero direcionamento',
      ctaAction: 'direcionamento'
    },
    {
      icon: Handshake,
      title: 'Para Parceiros',
      subtitle: 'Co-criação',
      color: '#FF2D83',
      painPoints: [
        'Soluções isoladas que não integram',
        'Necessidade de especialização complementar',
        'Busca por diferenciais competitivos',
        'Oportunidade de ampliar portfólio',
        'Desejo de criar valor conjunto'
      ],
      promise: 'Co-criamos soluções integradas que potencializam nossos conhecimentos e geram valor real para o mercado.',
      cta: 'Vamos co-criar',
      ctaAction: 'parceria'
    }
  ];

  return (
    <section id="para-quem" className="py-16 bg-gradient-to-b from-[#07070B] to-[#0a0a0f]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#F4F4F8] mb-4">
            Para{' '}
            <span className="bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
              Quem
            </span>
          </h2>
          <p className="text-xl text-[#C7C7D6] max-w-2xl mx-auto">
            Soluções estratégicas para empresas, profissionais e parceiros que buscam resultados sustentáveis
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {cards.map((card, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ scale: 1.03, y: -8 }}
              className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 hover:bg-white/10 hover:border-white/20 hover:shadow-2xl transition-all duration-300"
            >
              {/* Icon */}
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                style={{ backgroundColor: `${card.color}20`, border: `2px solid ${card.color}` }}
              >
                <card.icon size={32} style={{ color: card.color }} />
              </div>

              {/* Title */}
              <h3 className="text-2xl font-bold text-[#F4F4F8] mb-2">{card.title}</h3>
              <p className="text-sm text-[#C7C7D6] mb-6 font-medium" style={{ color: card.color }}>
                {card.subtitle}
              </p>

              {/* Pain Points */}
              <ul className="space-y-3 mb-6">
                {card.painPoints.map((point, i) => (
                  <li key={i} className="flex items-start gap-2 text-[#C7C7D6] text-sm">
                    <span
                      className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0"
                      style={{ backgroundColor: card.color }}
                    ></span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>

              {/* Promise */}
              <div className="p-4 bg-white/5 rounded-lg mb-6 border-l-4" style={{ borderColor: card.color }}>
                <p className="text-[#F4F4F8] text-sm leading-relaxed">{card.promise}</p>
              </div>

              {/* CTA */}
              <Button
                onClick={() => handleCTAClick(card.ctaAction)}
                className="w-full text-white font-semibold rounded-lg transition-all duration-300 hover:shadow-lg"
                style={{ backgroundColor: card.color }}
              >
                {card.cta}
                <ArrowRight className="ml-2" size={18} />
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ParaQuem;
