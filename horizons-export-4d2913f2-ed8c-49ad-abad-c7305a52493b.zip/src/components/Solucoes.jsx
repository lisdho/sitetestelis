
import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, BarChart3, Users } from 'lucide-react';

const Solucoes = () => {
  const pillars = [
    {
      icon: TrendingUp,
      title: 'Desenvolvimento de Carreira',
      subtitle: 'Pilar A',
      color: '#FF2D83',
      services: [
        'PDI - Plano de Desenvolvimento Individual',
        'Desenvolvimento de Liderança',
        'Transição de Carreira',
        'Planejamento de Sucessão',
        'Recolocação Profissional',
        'Mentoria Executiva',
        'Coaching Personalizado',
        'Desenvolvimento de Equipes'
      ]
    },
    {
      icon: BarChart3,
      title: 'People Analytics',
      subtitle: 'Pilar B',
      color: '#BDA0FF',
      services: [
        'Definição de KPIs de Pessoas',
        'Dashboards Executivos',
        'Relatórios Estratégicos',
        'Informes para Tomada de Decisão',
        'Análise de Turnover',
        'Métricas de Desempenho',
        'Indicadores de Engajamento',
        'ROI de Programas de Desenvolvimento'
      ]
    },
    {
      icon: Users,
      title: 'Clima e Cultura',
      subtitle: 'Pilar C',
      color: '#FF2D83',
      services: [
        'Pesquisa de Clima Organizacional',
        'Diagnóstico Cultural',
        'Programas de Integração',
        'Estratégias de Comunicação Interna',
        'Campanhas de Engajamento',
        'Gestão de Mudanças',
        'Fortalecimento de Valores',
        'Employee Experience'
      ]
    }
  ];

  return (
    <section id="solucoes" className="py-16 bg-[#07070B]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#F4F4F8] mb-4">
            Nossas{' '}
            <span className="bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
              Soluções
            </span>
          </h2>
          <p className="text-xl text-[#C7C7D6] max-w-2xl mx-auto">
            Três pilares integrados para transformar desafios em resultados sustentáveis
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pillars.map((pillar, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ scale: 1.02, y: -8 }}
              className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 hover:bg-white/10 hover:border-white/20 hover:shadow-2xl transition-all duration-300"
            >
              {/* Icon Header */}
              <div className="flex items-center gap-4 mb-6">
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${pillar.color}20`, border: `2px solid ${pillar.color}` }}
                >
                  <pillar.icon size={28} style={{ color: pillar.color }} />
                </div>
                <div>
                  <p className="text-xs font-semibold text-[#C7C7D6] mb-1" style={{ color: pillar.color }}>
                    {pillar.subtitle}
                  </p>
                  <h3 className="text-xl font-bold text-[#F4F4F8]">{pillar.title}</h3>
                </div>
              </div>

              {/* Services List */}
              <ul className="space-y-3">
                {pillar.services.map((service, i) => (
                  <motion.li
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: index * 0.2 + i * 0.05 }}
                    className="flex items-start gap-3 text-[#C7C7D6] text-sm group"
                  >
                    <span
                      className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0 group-hover:scale-125 transition-transform duration-300"
                      style={{ backgroundColor: pillar.color }}
                    ></span>
                    <span className="group-hover:text-[#F4F4F8] transition-colors duration-300">{service}</span>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Solucoes;
