
import React from 'react';
import { motion } from 'framer-motion';
import { Award, Briefcase, GraduationCap, Heart } from 'lucide-react';

const Fundadora = () => {
  const highlights = [
    {
      icon: Briefcase,
      label: '10+ Anos',
      description: 'Experiência em desenvolvimento humano',
      color: '#FF2D83'
    },
    {
      icon: Award,
      label: 'Multinacionais',
      description: 'Atuação em grandes empresas',
      color: '#BDA0FF'
    },
    {
      icon: GraduationCap,
      label: 'Empreendedorismo',
      description: 'Visão prática e estratégica',
      color: '#FF2D83'
    },
    {
      icon: Heart,
      label: 'Propósito',
      description: 'Pessoas no centro da estratégia',
      color: '#BDA0FF'
    }
  ];

  return (
    <section id="fundadora" className="py-16 bg-gradient-to-b from-[#07070B] to-[#0a0a0f]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#F4F4F8] mb-4">
            Quem está{' '}
            <span className="bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
              Por Trás
            </span>
          </h2>
        </motion.div>

        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            {/* Image Section */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden border-4 border-white/10 shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1659353219716-699803846194"
                  alt="Lisandra Lencina - Fundadora LENS Partner"
                  className="w-full h-auto object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#07070B]/50 to-transparent"></div>
              </div>

              {/* Decorative Elements */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-br from-[#FF2D83] to-[#BDA0FF] rounded-full opacity-20 blur-2xl"></div>
              <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gradient-to-br from-[#BDA0FF] to-[#FF2D83] rounded-full opacity-20 blur-2xl"></div>
            </motion.div>

            {/* Content Section */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h3 className="text-3xl md:text-4xl font-bold text-[#F4F4F8] mb-4">
                Lisandra Lencina
              </h3>
              <p className="text-lg text-[#BDA0FF] mb-6 font-medium">
                Fundadora e Consultora Principal
              </p>

              <div className="space-y-4 mb-8">
                <p className="text-[#C7C7D6] leading-relaxed">
                  Com mais de 10 anos de experiência em desenvolvimento humano, Lisandra construiu sua carreira 
                  atuando em multinacionais de diversos segmentos, onde liderou projetos estratégicos de gestão 
                  de pessoas, cultura organizacional e people analytics.
                </p>
                <p className="text-[#C7C7D6] leading-relaxed">
                  Sua trajetória como empreendedora a capacitou com uma visão única que integra o rigor técnico 
                  das grandes corporações com a agilidade e foco em resultados do mundo dos negócios.
                </p>
                <p className="text-[#C7C7D6] leading-relaxed">
                  Fundou a LENS Partner com o propósito de ajudar pessoas e organizações a alcançarem seus 
                  objetivos no tempo certo, através de estratégias conectadas à realidade e desenvolvimento 
                  sustentável.
                </p>
              </div>

              {/* Highlights Grid */}
              <div className="grid grid-cols-2 gap-4">
                {highlights.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-4 hover:bg-white/10 hover:border-white/20 transition-all duration-300"
                  >
                    <item.icon size={24} style={{ color: item.color }} className="mb-2" />
                    <p className="text-[#F4F4F8] font-semibold text-sm mb-1">{item.label}</p>
                    <p className="text-[#C7C7D6] text-xs">{item.description}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Fundadora;
