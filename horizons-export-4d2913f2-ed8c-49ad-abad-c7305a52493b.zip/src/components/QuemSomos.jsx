
import React from 'react';
import { motion } from 'framer-motion';
import { Target } from 'lucide-react';

const QuemSomos = () => {
  return (
    <section id="quem-somos" className="py-16 bg-[#07070B]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center"
        >
          {/* Section Title */}
          <div className="flex items-center justify-center gap-3 mb-8">
            <Target className="text-[#FF2D83]" size={32} />
            <h2 className="text-4xl md:text-5xl font-bold text-[#F4F4F8]">
              Quem{' '}
              <span className="bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
                Somos
              </span>
            </h2>
          </div>

          {/* About Content */}
          <div className="space-y-6">
            <p className="text-lg md:text-xl text-[#C7C7D6] leading-relaxed">
              A LENS Partner é uma consultoria especializada em desenvolvimento humano com foco em resultados mensuráveis. 
              Unimos estratégia, dados e pessoas para transformar desafios em oportunidades reais de crescimento.
            </p>

            <p className="text-lg md:text-xl text-[#C7C7D6] leading-relaxed">
              Trabalhamos com empresas B2B que buscam otimizar sua gestão de pessoas, profissionais que desejam 
              direcionar suas carreiras de forma estratégica, e parceiros que acreditam na co-criação de soluções inovadoras.
            </p>

            <p className="text-lg md:text-xl text-[#C7C7D6] leading-relaxed">
              Nossa abordagem integra o técnico e o humano, conectando diagnósticos precisos com execução prática 
              e acompanhamento contínuo.
            </p>

            {/* Mission Statement */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="mt-12 p-8 bg-gradient-to-br from-[#FF2D83]/10 to-[#BDA0FF]/10 backdrop-blur-sm border border-white/10 rounded-2xl"
            >
              <h3 className="text-xl font-semibold text-[#F4F4F8] mb-4">Nossa Missão</h3>
              <p className="text-lg text-[#C7C7D6] leading-relaxed italic">
                "Ajudar pessoas e negócios a se direcionarem aos seus objetivos no tempo certo, 
                para gerar resultados sustentáveis, por meio de estratégias conectadas à realidade."
              </p>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default QuemSomos;
