
import React from 'react';
import { motion } from 'framer-motion';
import { Search, FileText, Rocket, ShoppingBag, Calendar, Briefcase } from 'lucide-react';

const ComoTrabalhamos = () => {
  const steps = [
    {
      number: '01',
      title: 'Diagnóstico',
      description: 'Análise profunda da situação atual, identificando desafios, oportunidades e gaps através de dados qualitativos e quantitativos.',
      icon: Search,
      color: '#FF2D83'
    },
    {
      number: '02',
      title: 'Plano de Ação',
      description: 'Desenvolvimento de estratégias customizadas com objetivos claros, métricas definidas e cronograma realista.',
      icon: FileText,
      color: '#BDA0FF'
    },
    {
      number: '03',
      title: 'Execução',
      description: 'Implementação prática com acompanhamento contínuo, ajustes necessários e mensuração de resultados ao longo do processo.',
      icon: Rocket,
      color: '#FF2D83'
    }
  ];

  const formats = [
    {
      icon: ShoppingBag,
      title: 'Prateleira',
      description: 'Serviços prontos para atender demandas específicas de forma rápida e eficiente.',
      features: ['Entregas rápidas', 'Escopo pré-definido', 'Investimento fixo'],
      color: '#FF2D83'
    },
    {
      icon: Calendar,
      title: 'Assinatura',
      description: 'Acompanhamento contínuo ao longo de 12 meses com revisões periódicas e ajustes estratégicos.',
      features: ['Planejamento anual', 'Revisões trimestrais', 'Consultoria contínua'],
      color: '#BDA0FF'
    },
    {
      icon: Briefcase,
      title: 'Projetos',
      description: 'Soluções customizadas de 3 a 6 meses para transformações mais complexas e estratégicas.',
      features: ['Totalmente personalizado', 'Equipe dedicada', 'Resultados mensuráveis'],
      color: '#FF2D83'
    }
  ];

  return (
    <section id="como-trabalhamos" className="py-16 bg-gradient-to-b from-[#0a0a0f] to-[#07070B]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#F4F4F8] mb-4">
            Como{' '}
            <span className="bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
              Trabalhamos
            </span>
          </h2>
          <p className="text-xl text-[#C7C7D6] max-w-2xl mx-auto">
            Metodologia estruturada em 3 etapas para garantir resultados sustentáveis
          </p>
        </motion.div>

        {/* Process Steps */}
        <div className="max-w-6xl mx-auto mb-20">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-4 relative">
            {steps.map((step, index) => (
              <React.Fragment key={index}>
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className="relative"
                >
                  {/* Step Card */}
                  <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 hover:bg-white/10 hover:border-white/20 hover:shadow-2xl transition-all duration-300 h-full">
                    {/* Step Number */}
                    <div
                      className="text-6xl font-bold mb-4 opacity-20"
                      style={{ color: step.color }}
                    >
                      {step.number}
                    </div>

                    {/* Icon */}
                    <div
                      className="w-16 h-16 rounded-xl flex items-center justify-center mb-6"
                      style={{ backgroundColor: `${step.color}20`, border: `2px solid ${step.color}` }}
                    >
                      <step.icon size={32} style={{ color: step.color }} />
                    </div>

                    {/* Title */}
                    <h3 className="text-2xl font-bold text-[#F4F4F8] mb-4">{step.title}</h3>

                    {/* Description */}
                    <p className="text-[#C7C7D6] leading-relaxed">{step.description}</p>
                  </div>
                </motion.div>

                {/* Connector Arrow (Desktop only) */}
                {index < steps.length - 1 && (
                  <div className="hidden md:flex items-center justify-center absolute top-1/2 transform -translate-y-1/2"
                       style={{ left: `${(index + 1) * 33.33 - 4}%` }}>
                    <div className="w-8 h-0.5 bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF]"></div>
                    <div className="w-0 h-0 border-t-4 border-b-4 border-l-8 border-t-transparent border-b-transparent border-l-[#BDA0FF]"></div>
                  </div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* Formats Section */}
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h3 className="text-3xl md:text-4xl font-bold text-[#F4F4F8] mb-4">
              Formatos de{' '}
              <span className="bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
                Atendimento
              </span>
            </h3>
            <p className="text-lg text-[#C7C7D6] max-w-2xl mx-auto">
              Escolha o formato que melhor se adapta às suas necessidades e momento do negócio
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {formats.map((format, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                whileHover={{ scale: 1.03, y: -8 }}
                className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 hover:bg-white/10 hover:border-white/20 hover:shadow-2xl transition-all duration-300"
              >
                {/* Icon */}
                <div
                  className="w-16 h-16 rounded-xl flex items-center justify-center mb-6"
                  style={{ backgroundColor: `${format.color}20`, border: `2px solid ${format.color}` }}
                >
                  <format.icon size={32} style={{ color: format.color }} />
                </div>

                {/* Title */}
                <h4 className="text-2xl font-bold text-[#F4F4F8] mb-4">{format.title}</h4>

                {/* Description */}
                <p className="text-[#C7C7D6] mb-6 leading-relaxed">{format.description}</p>

                {/* Features */}
                <ul className="space-y-2">
                  {format.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-[#C7C7D6] text-sm">
                      <span
                        className="w-1.5 h-1.5 rounded-full"
                        style={{ backgroundColor: format.color }}
                      ></span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ComoTrabalhamos;
