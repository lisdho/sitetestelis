
import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HeroSection = () => {
  const handleCTAClick = (type) => {
    if (type === 'primary') {
      const element = document.querySelector('#contato');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    } else if (type === 'secondary') {
      const element = document.querySelector('#solucoes');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1652581234-26160f608093"
          alt="Professional business environment"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#07070B]/80 via-[#07070B]/70 to-[#07070B]/90"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-32">
        <div className="max-w-5xl mx-auto text-center">
          {/* Mini Proof */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <span className="inline-block px-4 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-[#C7C7D6] text-sm font-medium">
              Do técnico ao humano. Do diagnóstico à execução.
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl font-bold mb-6 leading-tight"
          >
            <span className="bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
              A direção do seu objetivo
            </span>
            <br />
            <span className="text-[#F4F4F8]">no tempo certo</span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-xl md:text-2xl text-[#C7C7D6] mb-12 max-w-3xl mx-auto leading-relaxed"
          >
            Estratégia conectada à realidade. Dados, método e desenvolvimento humano para resultados sustentáveis.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <Button
              onClick={() => handleCTAClick('primary')}
              size="lg"
              className="bg-[#FF2D83] hover:bg-[#FF2D83]/90 text-white px-8 py-6 text-lg font-semibold rounded-lg shadow-lg hover:shadow-[#FF2D83]/50 transition-all duration-300 hover:scale-105"
            >
              Agendar uma conversa
              <ArrowRight className="ml-2" size={20} />
            </Button>
            <Button
              onClick={() => handleCTAClick('secondary')}
              size="lg"
              variant="outline"
              className="border-2 border-[#BDA0FF] text-[#BDA0FF] hover:bg-[#BDA0FF]/10 px-8 py-6 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105 bg-transparent"
            >
              Ver soluções
              <Eye className="ml-2" size={20} />
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="w-6 h-10 border-2 border-[#BDA0FF] rounded-full flex items-start justify-center p-2"
        >
          <div className="w-1.5 h-1.5 bg-[#BDA0FF] rounded-full"></div>
        </motion.div>
      </motion.div>
    </section>
  );
};

export default HeroSection;
