
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, Target, Users, TrendingUp, Layers, Wrench } from 'lucide-react';

const Diferenciais = () => {
  const differentiators = [
    {
      icon: CheckCircle2,
      title: 'Casos Reais',
      description: 'Abordagem baseada em situações concretas e resultados mensuráveis, não apenas teoria.',
      color: '#FF2D83'
    },
    {
      icon: Target,
      title: 'Ciclo Completo',
      description: 'Do diagnóstico à execução, acompanhamos todo o processo com você.',
      color: '#BDA0FF'
    },
    {
      icon: Users,
      title: 'Do Técnico ao Humano',
      description: 'Integramos dados, processos e desenvolvimento de pessoas em uma única solução.',
      color: '#FF2D83'
    },
    {
      icon: TrendingUp,
      title: 'Adaptação Contínua',
      description: 'Ajustamos estratégias com base em resultados e mudanças do contexto.',
      color: '#BDA0FF'
    },
    {
      icon: Layers,
      title: 'Visão Sistêmica',
      description: 'Entendemos que cada solução impacta diferentes áreas do negócio e da vida profissional.',
      color: '#FF2D83'
    },
    {
      icon: Wrench,
      title: 'Ferramentas Práticas',
      description: 'Metodologias e instrumentos aplicáveis que você pode usar no dia a dia.',
      color: '#BDA0FF'
    }
  ];

  return (
    <section id="diferenciais" className="py-16 bg-[#07070B]">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[#F4F4F8] mb-4">
            Nossos{' '}
            <span className="bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
              Diferenciais
            </span>
          </h2>
          <p className="text-xl text-[#C7C7D6] max-w-2xl mx-auto">
            O que nos torna únicos na entrega de resultados sustentáveis
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {differentiators.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-6 hover:bg-white/10 hover:border-white/20 hover:shadow-2xl transition-all duration-300"
            >
              {/* Icon */}
              <div
                className="w-14 h-14 rounded-xl flex items-center justify-center mb-4"
                style={{ backgroundColor: `${item.color}20`, border: `2px solid ${item.color}` }}
              >
                <item.icon size={28} style={{ color: item.color }} />
              </div>

              {/* Title */}
              <h3 className="text-xl font-bold text-[#F4F4F8] mb-3">{item.title}</h3>

              {/* Description */}
              <p className="text-[#C7C7D6] text-sm leading-relaxed">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Diferenciais;
