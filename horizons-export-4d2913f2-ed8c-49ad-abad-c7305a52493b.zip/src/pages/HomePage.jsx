
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowRight, MessageCircle, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import HeroSection from '@/components/HeroSection';
import QuemSomos from '@/components/QuemSomos';
import ParaQuem from '@/components/ParaQuem';
import Solucoes from '@/components/Solucoes';
import ComoTrabalhamos from '@/components/ComoTrabalhamos';
import Diferenciais from '@/components/Diferenciais';
import Fundadora from '@/components/Fundadora';

const HomePage = () => {
  const { toast } = useToast();

  const handleCTAClick = (type) => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "Esta funcionalidade será implementada em breve. Por favor, entre em contato através da seção de contato!",
    });
  };

  return (
    <>
      <Helmet>
        <title>LENS Partner | Desenvolvimento Humano com resultado</title>
        <meta 
          name="description" 
          content="Consultoria que integra dados, método e desenvolvimento humano para resultados sustentáveis. Diagnóstico, people analytics, cultura e carreira." 
        />
      </Helmet>

      {/* Removed bg-[#07070B] to allow AbstractBackground to show through */}
      <div className="text-[#F4F4F8] relative">
        {/* Hero Section */}
        <HeroSection />

        {/* Quem Somos Section */}
        <QuemSomos />

        {/* Para Quem Section */}
        <ParaQuem />

        {/* Soluções Section */}
        <Solucoes />

        {/* Como Trabalhamos Section */}
        <ComoTrabalhamos />

        {/* Diferenciais Section */}
        <Diferenciais />

        {/* Fundadora Section */}
        <Fundadora />

        {/* Final CTA Section */}
        <section className="py-20 bg-gradient-to-b from-[#0a0a0f] to-[#07070B]">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="max-w-4xl mx-auto text-center"
            >
              {/* Headline */}
              <h2 className="text-4xl md:text-6xl font-bold text-[#F4F4F8] mb-6">
                Vamos{' '}
                <span className="bg-gradient-to-r from-[#FF2D83] to-[#BDA0FF] bg-clip-text text-transparent">
                  Juntos?
                </span>
              </h2>

              {/* Subheadline */}
              <p className="text-xl md:text-2xl text-[#C7C7D6] mb-12 leading-relaxed">
                Transforme desafios em vantagem competitiva sustentável. Estratégias conectadas à realidade, 
                resultados mensuráveis e desenvolvimento que faz diferença.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button
                  onClick={() => handleCTAClick('agendar')}
                  size="lg"
                  className="bg-[#FF2D83] hover:bg-[#FF2D83]/90 text-white px-8 py-6 text-lg font-semibold rounded-lg shadow-lg hover:shadow-[#FF2D83]/50 transition-all duration-300 hover:scale-105"
                >
                  Agendar reunião
                  <ArrowRight className="ml-2" size={20} />
                </Button>

                <Button
                  onClick={() => handleCTAClick('whatsapp')}
                  size="lg"
                  className="bg-[#BDA0FF] hover:bg-[#BDA0FF]/90 text-white px-8 py-6 text-lg font-semibold rounded-lg shadow-lg hover:shadow-[#BDA0FF]/50 transition-all duration-300 hover:scale-105"
                >
                  WhatsApp
                  <MessageCircle className="ml-2" size={20} />
                </Button>

                <Button
                  onClick={() => handleCTAClick('email')}
                  size="lg"
                  variant="outline"
                  className="border-2 border-white/20 text-[#F4F4F8] hover:bg-white/10 px-8 py-6 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105 bg-transparent"
                >
                  Email
                  <Mail className="ml-2" size={20} />
                </Button>
              </div>

              {/* Trust Badge */}
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="mt-12 inline-block px-6 py-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full"
              >
                <p className="text-[#C7C7D6] text-sm">
                  ✨ Primeira conversa sem compromisso • Diagnóstico gratuito disponível
                </p>
              </motion.div>
            </motion.div>
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;
